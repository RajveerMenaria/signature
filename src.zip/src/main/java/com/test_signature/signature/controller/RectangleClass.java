package com.test_signature.signature.controller;

import com.test_signature.signature.services.PDFWordLocator;
import com.test_signature.signature.services.SignatureClass;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.pdfbox.text.PDFTextStripperByArea;
import org.apache.pdfbox.text.TextPosition;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.awt.geom.Rectangle2D;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/check")
public class RectangleClass {

    @GetMapping
    public void getArea() throws IOException, UnrecoverableKeyException, CertificateException, KeyStoreException, NoSuchAlgorithmException {
        File file = new File("/home/nvl/Downloads/sample.pdf");
        PDDocument document = PDDocument.load(file);
        //PDPage page = findPageWithWord(document, "volutpat");
        // Extract text from the PDF document
        PDFTextStripper pdfStripper = new PDFTextStripper();
        String pdfText = pdfStripper.getText(document);
        SignatureClass sc = new SignatureClass();

        //sc.createSign(document, "Pellentesque");

        // Check if the word exists in the text
        if (pdfText.contains("volutpat")) {
           // System.out.println("The word is found in the PDF.");
            PDFWordLocator pd = new PDFWordLocator("volutpat");
            pd.getText(document);
            //pd.generateSignature(document, "volutpat");
            List<PDFWordLocator.WordPosition> positions = pd.getWordPositions();

            if (positions.isEmpty()) {
                System.out.println("is NOT found ");
            } else {
                System.out.println(" is found at:");
                for (PDFWordLocator.WordPosition position : positions) {
                    System.out.println(position);
                }
                sc.createSign(document, "Pellentesque", positions);
            }
        } else {
           System.out.println("not");
        }

        // Close the document
        document.close();


    }

}
