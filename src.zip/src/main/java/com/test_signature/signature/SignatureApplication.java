package com.test_signature.signature;

import com.itextpdf.kernel.pdf.StampingProperties;
import com.test_signature.signature.controller.RectangleClass;
import com.test_signature.signature.services.PDFWordLocator;
import com.test_signature.signature.services.SignatureClass;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.bouncycastle.pqc.jcajce.provider.BouncyCastlePQCProvider;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.itextpdf.forms.PdfAcroForm;
import com.itextpdf.forms.fields.PdfFormField;
import com.itextpdf.io.image.ImageData;
import com.itextpdf.io.image.ImageDataFactory;
import com.itextpdf.kernel.geom.Rectangle;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfReader;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.element.Image;
import com.itextpdf.signatures.*;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.security.*;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.util.List;

@SpringBootApplication
public class SignatureApplication {

	public static void main(String[] args) throws IOException, GeneralSecurityException {
		SpringApplication.run(SignatureApplication.class, args);
//		RectangleClass rect = new RectangleClass();
//		rect.getArea();
		//Security.addProvider(new BouncyCastlePQCProvider());
		Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider());
		String src = "/home/nvl/Downloads/sample.pdf";
		String dest = "/home/nvl/Downloads/output_signed.pdf";
		String keystorePath = "/home/nvl/Downloads/pfxfile.p12";
		char[] password = "test".toCharArray();
		String reason = "Reason for signing";
		String location = "Location";

		// Load the keystore
		KeyStore ks = KeyStore.getInstance("PKCS12");
		ks.load(new FileInputStream(keystorePath), password);
		String alias = ks.aliases().nextElement();
		PrivateKey pk = (PrivateKey) ks.getKey(alias, password);
		Certificate[] chain = ks.getCertificateChain(alias);

		// Create reader and stamper
		PdfReader reader = new PdfReader(src);
		PdfWriter writer = new PdfWriter(dest);
		PdfDocument pdfDoc = new PdfDocument(reader, writer);

		// Find the text position
		Rectangle rect = findTextPosition(pdfDoc, "Sign here");

		reader = new PdfReader(src);
		// Add signature
		PdfSigner signer = new PdfSigner(reader, writer, new StampingProperties());
		signer.setFieldName("sig");

		// Appearance
		PdfSignatureAppearance appearance = signer.getSignatureAppearance()
				.setReason(reason)
				.setLocation(location)
				.setPageRect(rect)
				.setPageNumber(1);
				//.setSignatureGraphic(ImageDataFactory.create("path/to/signature/image.png"))
				//.setRenderingMode(PdfSignatureAppearance.RenderingMode.GRAPHIC_AND_DESCRIPTION);

		signer.setFieldName("sig");
		signer.signDetached(new BouncyCastleDigest(), new PrivateKeySignature(pk, DigestAlgorithms.SHA256, "BC"), chain, null, null, null, 0, PdfSigner.CryptoStandard.CMS);

		System.out.println("Pdf signed");
	}

	private static Rectangle findTextPosition(PdfDocument pdfDoc, String text) throws IOException {
		File file = new File("/home/nvl/Downloads/sample.pdf");
		PDDocument document = PDDocument.load(file);
		// Extract text from the PDF document
		PDFTextStripper pdfStripper = new PDFTextStripper();
		String pdfText = pdfStripper.getText(document);
		SignatureClass sc = new SignatureClass();

		//sc.createSign(document, "Pellentesque");
		float x = 0, y= 0;
		// Check if the word exists in the text
		if (pdfText.contains("Morbi")) {
			// System.out.println("The word is found in the PDF.");
			PDFWordLocator pd = new PDFWordLocator("Morbi");
			pd.getText(document);
			//pd.generateSignature(document, "simple");

			List<PDFWordLocator.WordPosition> positions = pd.getWordPositions();
			for (PDFWordLocator.WordPosition position : positions) {
				System.out.println(position.startX);
				System.out.println(position.startY);
				x = position.startX;
				y = position.startY;

			}

		}
		return new Rectangle(x, -y, 50, 50);
    }
}
