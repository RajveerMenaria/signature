package com.test_signature.signature.services;

import org.apache.pdfbox.pdmodel.interactive.digitalsignature.SignatureInterface;

import java.io.IOException;
import java.io.InputStream;
import java.security.*;
import java.security.cert.Certificate;

public class CustomSignatureInterface implements SignatureInterface {

    private final PrivateKey privateKey;
    private final Certificate[] certChain;

    public CustomSignatureInterface(PrivateKey privateKey, Certificate[] certChain) {
        this.privateKey = privateKey;
        this.certChain = certChain;
    }

    @Override
    public byte[] sign(InputStream content) throws IOException {
        try {
            // Create the signature
            Signature signature = Signature.getInstance("SHA256withRSA");
            signature.initSign(privateKey);
            byte[] buffer = new byte[8192];
            int len;
            while ((len = content.read(buffer)) != -1) {
                signature.update(buffer, 0, len);
            }
            return signature.sign();
        } catch (GeneralSecurityException e) {
            throw new IOException("Error while creating the signature", e);
        }
    }
}
