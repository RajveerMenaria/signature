package com.test_signature.signature.services;

import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.interactive.digitalsignature.visible.PDVisibleSigProperties;

import java.io.InputStream;

public class PDProps extends PDVisibleSigProperties {

    private PDRectangle rectangle;
    private PDPage pdPage;
    private InputStream visibleSignature;

    public PDRectangle getRectangle() {
        return rectangle;
    }

    public void setRectangle(PDRectangle rectangle) {
        this.rectangle = rectangle;
    }

    public PDPage getPdPage() {
        return pdPage;
    }

    public void setPdPage(PDPage pdPage) {
        this.pdPage = pdPage;
    }

    public void setVisibleSignature(InputStream visibleSignature) {
        this.visibleSignature = visibleSignature;
    }
}
