package com.test_signature.signature.services;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.interactive.digitalsignature.PDSignature;
import org.apache.pdfbox.pdmodel.interactive.digitalsignature.SignatureOptions;
import org.apache.pdfbox.pdmodel.interactive.digitalsignature.visible.PDVisibleSigProperties;
import org.apache.pdfbox.pdmodel.interactive.digitalsignature.visible.PDVisibleSignDesigner;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.pdfbox.text.PDFTextStripperByArea;
import org.apache.pdfbox.text.TextPosition;

import java.io.FileInputStream;
import java.io.IOException;
import java.security.*;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.util.Calendar;
import java.util.LinkedList;
import java.util.List;

public class SignatureClass {


    String keystorePath = "/home/nvl/Downloads/pfxfile.p12";
    // Keystore password
    String keystorePassword = "test";
    // Alias of the key pair in the keystore
    String alias = "alias";
    // Password of the key pair
    String keyPassword = "test";


    public void createSign(PDDocument document, String wordToFind, List<PDFWordLocator.WordPosition> lst1) throws KeyStoreException, UnrecoverableKeyException, NoSuchAlgorithmException, IOException, CertificateException {
        for (PDFWordLocator.WordPosition position : lst1) {
            System.out.println(position.startX);
            System.out.println(position.startY);
        }
        System.out.println("pos string= "+lst1.get(lst1.size()-1).startX);
        PDPage page = findPageWithWord(document, wordToFind);
        if (page != null) {
            //List<Float> lst = findWordCoordinates(document, page, wordToFind);

            float coordinates[] = new float[2];
            coordinates[0] = lst1.get(lst1.size()-1).startX;
            coordinates[1] = lst1.get(lst1.size()-1).startY;
            if (coordinates != null) {
                // Create a signature
                PDSignature signature = new PDSignature();
                signature.setFilter(PDSignature.FILTER_ADOBE_PPKLITE);
                signature.setSubFilter(PDSignature.SUBFILTER_ADBE_PKCS7_DETACHED);
                signature.setName("Your Name");
                signature.setLocation("Your Location");
                signature.setReason("Your Reason");
                signature.setSignDate(Calendar.getInstance());

                // Load keystore
                KeyStore keystore = KeyStore.getInstance("PKCS12");
                keystore.load(new FileInputStream(keystorePath), keystorePassword.toCharArray());

                // Retrieve the signing key
                PrivateKey privateKey = (PrivateKey) keystore.getKey(alias, keyPassword.toCharArray());
                Certificate[] certChain = keystore.getCertificateChain(alias);

                // Create visual signature properties
               // PDVisibleSigProperties visibleSigProperties = createVisualSignature(document, page, coordinates);

                // Sign the document
                SignatureOptions signatureOptions = new SignatureOptions();
                //signatureOptions.setVisualSignature(visibleSigProperties);
                signatureOptions.setPage(document.getPages().indexOf(page)); // Sign the page with the word

                document.addSignature(signature, new CustomSignatureInterface(privateKey, certChain), signatureOptions);

                // Save the signed PDF
                document.save("/home/nvl/Downloads/signed-document.pdf");

                System.out.println("PDF document signed successfully at the position of the word: '" + wordToFind + "'.");
            } else {
                System.out.println("Failed to find the coordinates of the word '" + wordToFind + "'.");
            }
        }
    }

    private static PDPage findPageWithWord(PDDocument document, String wordToFind) throws IOException {
        System.out.println("pages= "+document.getNumberOfPages());
        for (PDPage page : document.getPages()) {
            PDFTextStripper stripper = new PDFTextStripper();
            stripper.setStartPage(document.getPages().indexOf(page) + 1);
            stripper.setEndPage(document.getPages().indexOf(page) + 1);
            String text = stripper.getText(document);
            if (text.contains(wordToFind)) {
                return page;
            }
        }
        return null;
    }

    private static PDVisibleSigProperties createVisualSignature(PDDocument document, PDPage page, float[] coordinates) throws IOException {
        PDRectangle rect = new PDRectangle(coordinates[0], coordinates[1] - 50, 150, 50); // Adjust as needed
        PDVisibleSigProperties pd =new PDVisibleSigProperties();
        // Create a content stream to draw the signature appearance
        try (PDPageContentStream contentStream = new PDPageContentStream(document, page, PDPageContentStream.AppendMode.APPEND, true)) {
            contentStream.addRect(rect.getLowerLeftX(), rect.getLowerLeftY(), rect.getWidth(), rect.getHeight());
            contentStream.setNonStrokingColor(255, 255, 255); // White background
            contentStream.fill();
            contentStream.setNonStrokingColor(0, 0, 0); // Black text
            contentStream.beginText();
            contentStream.setFont(PDType1Font.HELVETICA_BOLD, 12);
            contentStream.newLineAtOffset(rect.getLowerLeftX() + 5, rect.getLowerLeftY() + 5);
            contentStream.showText("Digitally Signed by Your Name");
            contentStream.endText();
        }

        return null;
    }
//    public static float startX = 0, startY = 0, endX = 0, endY = 0;
//
//    private static List<Float> findWordCoordinates(PDDocument document, PDPage page, String wordToFind) throws IOException {
//        List<Float> lst = new LinkedList<>();
//        StringBuilder word = new StringBuilder();
//
//        PDFTextStripper stripper = new PDFTextStripper() {
//            @Override
//            protected void writeString(String string, List<TextPosition> textPositions) throws IOException {
//                System.out.println("11111111");
//                for (TextPosition text : textPositions) {
//                    //System.out.println("66666666666");
//                    String charStr = text.getUnicode();
//
//                    if (word.length() == 0) {
//                        lst.clear();
//                        startX = text.getXDirAdj();
//                        startY = text.getYDirAdj();
//                        lst.add(startX);
//                        lst.add(startY);
//                    }
//                   // System.out.println("sig======= "+wordToFind);
//                    word.append(charStr);
//                    if (charStr.equals(" ") || charStr.equals("\n")) {
//                        word.setLength(0);  // reset the word
//                    } else if (word.toString().equalsIgnoreCase(wordToFind)) {
//                        word.setLength(0);  // reset the word after finding
//                        break;
//                    }
//                }
//            }
//        };
//
//        float[] wordCoords = new float[2];
//        stripper.setStartPage(document.getPages().indexOf(page) + 1);
//        stripper.setEndPage(document.getPages().indexOf(page) + 1);
//        stripper.getText(document);
//        return lst;
//    }
}
