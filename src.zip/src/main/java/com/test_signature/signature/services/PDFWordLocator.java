package com.test_signature.signature.services;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.pdfbox.text.TextPosition;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class PDFWordLocator extends PDFTextStripper {

    private List<WordPosition> wordPositions = new LinkedList<>();
    private String searchWord;

    public PDFWordLocator(String searchWord) throws IOException {
        this.searchWord = searchWord;
    }

    @Override
    protected void writeString(String string, List<TextPosition> textPositions) throws IOException {
        //System.out.println("44444444444");
        StringBuilder word = new StringBuilder();
        float startX = 0, startY = 0, endX = 0, endY = 0;
        //System.out.println("555555555");
        for (TextPosition text : textPositions) {
            //System.out.println("66666666666");
            String charStr = text.getUnicode();

            if (word.length() == 0) {
                startX = text.getXDirAdj();
                startY = text.getYDirAdj();
            }
           // System.out.println("777777777777777= "+word);
           // System.out.println("888888888888888= "+searchWord);
            word.append(charStr);
            endX = text.getXDirAdj() + text.getWidthDirAdj();
            endY = text.getYDirAdj() + text.getHeightDir();

            if (charStr.equals(" ") || charStr.equals("\n")) {
                word.setLength(0);  // reset the word
            } else if (word.toString().equalsIgnoreCase(searchWord)) {
                wordPositions.add(new WordPosition(searchWord, startX+50, startY, endX, endY));
                word.setLength(0);  // reset the word after finding
                break;
            }


        }
    }

    public List<WordPosition> getWordPositions() {
        //System.out.println("11111111111");
        return wordPositions;
    }



    public static class WordPosition {
        String word;
        public float startX;
        public float startY;
        float endX;
        float endY;

        public WordPosition(String word, float startX, float startY, float endX, float endY) {
            //System.out.println("2222222222");
            this.word = word;
            this.startX = startX;
            this.startY = startY;
            this.endX = endX;
            this.endY = endY;
        }

        @Override
        public String toString() {
            //System.out.println("3333333333333");
            return "Word: " + word + " [startX=" + startX + ", startY=" + startY + ", endX=" + endX + ", endY=" + endY + "]";
        }
    }

}


