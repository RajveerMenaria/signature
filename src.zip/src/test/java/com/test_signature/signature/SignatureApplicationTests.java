package com.test_signature.signature;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SignatureApplicationTests {

	@Test
	void contextLoads() {
	}

}
